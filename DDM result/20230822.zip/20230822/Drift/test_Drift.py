import Drift
import numpy as np

drift0 = 1.0
x_bound = 1.0
dx = 0.1
dt = 0.1

# numpy_array = Drift.test_get_flux_constant(drift0, x_bound, dx, dt)
# print(numpy_array)

B = 0.5
drift0 = 1.0
t = 0
dt = 0.1
dx = 0.1
x = np.arange(-B, B + 0.1 * dx, dx)
# res = Drift.test_get_matrix_constant(drift0, dx, dt, t, x)
# print("Drift matrix: ", res.shape)
# print(res)


res = Drift.test_get_matrix("constant", drift0, dx, dt, t, x)
print("Drift matrix: ", res.shape)
print(res)
