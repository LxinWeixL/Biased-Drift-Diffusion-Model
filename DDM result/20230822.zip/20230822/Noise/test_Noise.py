import Noise
import numpy as np
import matplotlib.pyplot as plt

# Case 1
B = 0.5
s0 = 1.0
dx = 0.1
time_vector = np.arange(0.0, 3.0, dx)
evidence_vector = np.arange(-B, B+dx, dx)
t = time_vector[0]
dt = 0.1

# res1 = Noise.test_get_matrix_constant(evidence_vector, s0, t, dx, dt)
# print("Matrix dimension ", res1.shape)
# np.savetxt("res1.csv", res1, delimiter=",")


res1 = Noise.test_get_matrix("constant", evidence_vector, s0, t, dx, dt)
print("Matrix dimension ", res1.shape)
print("Matrix ", res1)