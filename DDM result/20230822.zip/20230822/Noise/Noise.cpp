#include <iostream>
#include <string>
#include <cctype> // tolower
#include <armadillo>
#include <boost/math/distributions/normal.hpp>

#include "Dependence.hpp"
#include "Noise.hpp"

#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>

namespace py = pybind11;

py::array_t<double> armadilloToNumpy(const arma::mat &mat)
{
    // Get dimensions of the matrix
    ssize_t rows = mat.n_rows;
    ssize_t cols = mat.n_cols;

    // Create a Pybind11 array with the same shape as the Armadillo matrix
    py::array_t<double> result({rows, cols});

    // Get a pointer to the data in the Armadillo matrix
    const double *data = mat.memptr();

    // Get a pointer to the data in the Pybind11 array
    double *result_data = result.mutable_data();

    // Copy data from Armadillo matrix to Pybind11 array
    std::memcpy(result_data, data, sizeof(double) * rows * cols);

    return result;
}

py::array_t<double> test_get_matrix_constant(const py::array_t<double> &x, double s0, double t, double dx, double dt)
{
    py::buffer_info buf_info = x.request();
    if (buf_info.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }
    double *data_ptr = static_cast<double *>(buf_info.ptr);
    arma::vec x_arma_vec(data_ptr, buf_info.size);

    Noise *ptr = new Noise("constant", "Noise", s0);
    ptr->print_name();

    arma::sp_mat A = ptr->get_matrix(x_arma_vec, t, dx, dt); // t is unused in 0
    arma::mat A_out = arma::mat(A);
    py::array_t<double> out = armadilloToNumpy(A_out);
    return out;
}

py::array_t<double> test_get_matrix(std::string s, const py::array_t<double> &x, double s0, double t, double dx, double dt)
{
    py::buffer_info buf_info = x.request();
    if (buf_info.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }
    double *data_ptr = static_cast<double *>(buf_info.ptr);
    arma::vec x_arma_vec(data_ptr, buf_info.size);

    Noise *ptr = new Noise(s, "Noise", s0);
    ptr->print_name();

    arma::sp_mat A = ptr->get_matrix(x_arma_vec, t, dx, dt); // t is unused in 0
    arma::mat A_out = arma::mat(A);
    py::array_t<double> out = armadilloToNumpy(A_out);
    return out;
}

PYBIND11_MODULE(Noise, m)
{
    m.doc() = "Noise module";
    m.def("test_get_matrix_constant", &test_get_matrix_constant,
          "Calculate the diffusion matrice for a constant noise");
    m.def("test_get_matrix", &test_get_matrix, 
    "Calculate the diffusion matrice for a constant noise");
}
