import Bound
import numpy as np
b0 = 1.0

# time_coefficient is not used in the case of a constant boundary.
time_coefficient = 1.0
dt = 0.1
time_vector = np.arange(0.0, 5.0, dt) 

res = Bound.test_Bound(b0, time_coefficient, time_vector)
# transpose the result to get a row vector
res1 = res.T
print(res1)

