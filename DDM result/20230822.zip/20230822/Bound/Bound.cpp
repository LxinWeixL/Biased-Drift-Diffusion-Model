#include <iostream>
#include <string>
#include <cctype> // tolower
#include <armadillo>

#include "Dependence.hpp"
#include "Bound.hpp"

#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <armadillo>

namespace py = pybind11;

py::array_t<double> armadilloToNumpy(const arma::mat &mat)
{
    // Get dimensions of the matrix
    ssize_t rows = mat.n_rows;
    ssize_t cols = mat.n_cols;

    // Create a Pybind11 array with the same shape as the Armadillo matrix
    py::array_t<double> result({rows, cols});

    // Get a pointer to the data in the Armadillo matrix
    const double *data = mat.memptr();

    // Get a pointer to the data in the Pybind11 array
    double *result_data = result.mutable_data();

    // Copy data from Armadillo matrix to Pybind11 array
    std::memcpy(result_data, data, sizeof(double) * rows * cols);

    return result;
}

py::array_t<double> test_Bound(double b0, double time_coefficient, const py::array_t<double> &time_vector)
{
    py::buffer_info buf_info = time_vector.request();

    if (buf_info.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }

    double *data_ptr = static_cast<double *>(buf_info.ptr);
    arma::vec time_vector_arma(data_ptr, buf_info.size);

    Bound *p_bound;
    p_bound = new Bound("constant", "Bound", b0);
    p_bound->print_name();
    arma::vec output_vec(time_vector_arma.n_elem);
    for (size_t j = 0; j < time_vector_arma.n_elem; j++)
        output_vec[j] = p_bound->get_bound(time_vector_arma[j]);

    delete p_bound;
    py::array_t<double> out = armadilloToNumpy(output_vec);
    return out;
}

PYBIND11_MODULE(Bound, m)
{
    m.doc() = "Bound module";
    m.def("test_Bound", &test_Bound,
          "Calculate the symmetrical boundary.");
}
