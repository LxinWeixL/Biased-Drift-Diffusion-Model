rm(list = ls())
pkg <- c("data.table", "ggplot2", "psych")
tmp_sink <- sapply(pkg, require, character.only = TRUE)
setwd("/media/yslin/kakapu/02_Projects/Multi-choices_Github/tests/Model_Age_old")

# Load the Video data ---------------------------------------------------------
# Forty subjects took part in 16 task scenarios. The experimenter used
# Scenario 16 as a condition to test whether the subject paid attention
# to the task.
d <- fread("data/video.csv")
names(d) <- c("Serial_number", "s", "Scenario_ID", "Scenario_Type", "Age_L", "Age_R",
    "Gender_L", "Gender_R", "R", "RT", "Initial_AV_location", "Subject_Age",
    "Subject_Gender")
names(d)

# Theoretically, the total number of trials is 2400 (or 2560, if
# we consider the control condition has the same number of trial
# as the other. 16 conditions, each has 4 repetitions, and 40 subjects.
15 * 4 * 40  # 2400
16 * 4 * 40  # 2560

nrow(d)  # Why did the difference of 4. 2560 - 2556

d1 <- d[!is.na(d$Scenario_Type)]
nrow(d1) # 2396
d2 <- d1[!is.na(d1$RT)]
nrow(d2) # 2126

table(d2$Scenario_Type)
#  AGE AGE+GENDER     GENDER 
#  722        992        412 

d3 <- d2[Scenario_Type == "AGE", c("s", "RT", "R", "Scenario_Type", "Gender_L", "Gender_R", "Age_L", "Age_R")]
describe(d3$RT)
#     n mean   sd median trimmed  mad  min  max range skew kurtosis   se
#   722 4.88 4.41      4    4.19 2.02 1.01 71.5 70.48 7.12    82.89 0.16
#
# Based on the interaction plot in the report, it looked like the age
# factor has an effect, child vs (yound or old) Therefore, I assumed
# that the subject biased towards selecting the older pedestrian be run over.
#
# This decision resulted in making the age (A) a two-level factor, namely
# child vs [adult] (level 1); old vs young (level 2). adult = young or old.
# 
# I assumed no left versus right bias, so I combined the left and right trial.
# A = Age factor with two levels
d3$A <- ifelse(d3$Age_L == "child" & d3$Age_R == "young", 1,
        ifelse(d3$Age_L == "child" & d3$Age_R == "old",   1,
        ifelse(d3$Age_L == "young" & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "young", 2,
        ifelse(d3$Age_L == "young" & d3$Age_R == "old",   2, NA))))))

# Check the code is run as expected.
unique(d3$A)
table(d3$A)
sum(table(d3$A))

# Match the record response to the model boundary. 0 = positive boundary to 
# crash the child pedestrian. 1 = negative boundary to crash the adult 
# pedestrian.
d3$TrueR <- ifelse(d3$Age_L == "child" & d3$Age_R == "old"   & d3$R == "L", 0,
            ifelse(d3$Age_L == "child" & d3$Age_R == "young" & d3$R == "L", 0,
            ifelse(d3$Age_L == "child" & d3$Age_R == "young" & d3$R == "R", 1,
            ifelse(d3$Age_L == "child" & d3$Age_R == "old"   & d3$R == "R", 1,

            ifelse(d3$Age_L == "old"   & d3$Age_R == "child" & d3$R == "L", 1,
            ifelse(d3$Age_L == "old"   & d3$Age_R == "young" & d3$R == "L", 1,
            ifelse(d3$Age_L == "old"   & d3$Age_R == "child" & d3$R == "R", 0,
            ifelse(d3$Age_L == "old"   & d3$Age_R == "young" & d3$R == "R", 0,
 
            ifelse(d3$Age_L == "young" & d3$Age_R == "child" & d3$R == "L", 1,
            ifelse(d3$Age_L == "young" & d3$Age_R == "old"   & d3$R == "L", 0,
            ifelse(d3$Age_L == "young" & d3$Age_R == "child" & d3$R == "R", 0,
            ifelse(d3$Age_L == "young" & d3$Age_R == "old"   & d3$R == "R", 1, 
            NA))))))))))))

nrow(d3) # 722
unique(d3$TrueR)
sum(table(d3$TrueR))

# When the level involves a child, people tend to select the adult as the
# victim, whereas, when the level does not involve a child, people tend to 
# select the young person as the victim. However, the tendency appeared not 
# exceeed the significant level. That is, it either did not exist or the power
# to detect such an effect is insufficient.

# Remove outliers 
lower <- mean(d3$RT) - 2 * sd(d3$RT)
upper <- mean(d3$RT) + 2 * sd(d3$RT)
# Remove 20 outliers
d4 <- d3[d3$RT < upper & d3$RT > lower, c("RT", "TrueR", "A", "s")]

1 - nrow(d4) / nrow(d3)
# 0.02770083; 2.8% of the data were removed. That is, 20 trials.

table(d4$TrueR)
nrow(d3) - nrow(d4)

# The overall choice probability towards crashing the young person is 0.31.
#   0   1 
# 217 485 
table(d4$TrueR)[1] / nrow(d4)
table(d4$TrueR)[1] / sum(table(d4$TrueR))


tbl <- table(d4$TrueR, d4$A)
#    involve child (1)   without child (2)
#   0          108             109
#   1          311             174
#             0.26            0.39  
#             0.74            0.61
round( 108/ (108 + 311), 2)
round( 311/ (108 + 311), 2)

round( 109/ (109 + 174), 2)
round( 174/ (109 + 174), 2)

# The chi-square test of independence showed that the two factors --
# (1) involving child or not (2) selecting to crash on child vs. adult 
# -- not independent, meaning that the participant's selection does
# depend on whether a child pedestrain was present.

chisq.test(tbl)
# Pearson's Chi-squared test with Yates' continuity correction
# data:  tbl
# X-squared = 12.248, df = 1, p-value = 0.0004657

# Check over the trial number at each condition in each subject.
sort(d4[A==1, .N, .(s)]$N)
sort(d4[A==2, .N, .(s)]$N)
#   6  6  6  8  9  9  9  9 10 10 10 10 10 10 10 11 11 11 11 11 11 11 11 11 11
#  11 11 11 12 12 12 12 12 12 12 12 12 12 12 12
#   4 5 5 5 5 5 5 6 6 6 6 7 7 7 7 7 7 7 8 8 8 8 8 8 8 8 8 8 8 8 8 8 8 8 8 8 8 8
#   8 8

describe(d4[A==1, .N, .(s)]$N)
describe(d4[A==2, .N, .(s)]$N)
#      n  mean   sd median trimmed  mad min max range  skew kurtosis   se
# A1  40 10.47 1.66     11   10.78 1.48   6  12     6 -1.37     1.32 0.26
#      n  mean   sd median trimmed  mad min max range  skew kurtosis   se
# A2  40  7.08 1.23      8    7.25    0   4   8     4 -0.95    -0.56 0.19
# write.csv(d4[A == 1], "data/age1.csv", row.names = FALSE)
# write.csv(d4[A == 2], "data/age2.csv", row.names = FALSE)


# Plot parameter and likleihood evolution -------------------------------------
# Plot the evolution of parameter ------------
source("utility/resources.R")

estimate_file <- "data/estimate_output_age1.txt"
likelihood_file <- "data/likelihood_output_age1.txt"
plot_evolution(estimate_file, likelihood_file, save = TRUE, 
    filename = "images/age1.png")

estimate_file <- "data/estimate_output_age2.txt"
likelihood_file <- "data/likelihood_output_age2.txt"
plot_evolution(estimate_file, likelihood_file, save = TRUE, 
    filename = "images/age2.png")

# Plot goodness of fit ----------------------
dsim1 <- fread("data/age1_simulation.csv")
demp1 <- fread("data/age1.csv")
dsim2 <- fread("data/age2_simulation.csv")
demp2 <- fread("data/age2.csv")
names(demp1) <- c("RT", "R", "A")
names(demp2) <- c("RT", "R", "A")

dsim1$A <- "With child pedestrian"
dsim2$A <- "Without child pedestrian"

dsim1$R <- ifelse(dsim1$R == 0, "Select a child victim", 
    "Select an adult victim")
demp1$R <- ifelse(demp1$R == 0, "Select a child victim", 
    "Select an adult victim")

dsim2$R <- ifelse(dsim2$R == 0, "Select a young victim", 
    "Select an old victim")
demp2$R <- ifelse(demp2$R == 0, "Select a young victim", 
    "Select an old victim")

demp1$A <- ifelse(demp1$A == 1, "With child pedestrian", 
    "Without child pedestrian")
demp2$A <- ifelse(demp2$A == 1, "With child pedestrian", 
    "Without child pedestrian")

binsize <- 40
p1 <- ggplot() +
  geom_histogram(data = dsim1, aes(x = RT, fill = "Simulation Data"), 
    bins = binsize, alpha = 0.5) +
  geom_histogram(data = demp1, aes(x = RT, fill = "Empirical Data"), 
    bins = binsize, alpha = 0.5) +
  facet_grid(R ~ .) +
  ggtitle("With child pedestrian") +
  theme_classic(base_size = 24) +
  scale_fill_manual(values=c("Empirical Data"="blue", "Simulation Data"="red")) +
  theme(legend.position = "top",
        legend.title = element_blank())



p2 <- ggplot() +
  geom_histogram(data = demp2, aes(x = RT, fill = "Empirical Data"), 
    bins = 35, alpha = 0.5) +
  geom_histogram(data = dsim2, aes(x = RT, fill = "Simulation Data"), 
    bins = 35, alpha = 0.5) +
  scale_y_continuous(limit = c(0, 55)) +
  facet_grid(R ~ .) +
  ggtitle("No child pedestrian") +
  theme_classic(base_size = 24) +
  scale_fill_manual(values=c("Empirical Data"="blue", "Simulation Data"="red")) +
  theme(legend.position = "top",
        legend.title = element_blank())
p3 <- gridExtra::grid.arrange(p1, p2, nrow = 1)
ggsave("images/age_scenario.png", p3, width = 12, height = 8)


