plot_evolution <- function(input1, input2, save = TRUE, filename = NULL) {
    library(data.table)
    library(ggplot2)
    library(gridExtra)

    dparameter <- fread(input1)
    dlik <- fread(input2)

    dparameter$iteration <- 1:nrow(dparameter)
    dlik$iteration <- 1:nrow(dlik)

    names(dparameter) <- c("drift", "bound", "ndt", "iteration")
    names(dlik) <- c("n2LL", "iteration")

    half_iter <- nrow(dparameter)/ 2

    dtext1 <- data.table(
        x = rep(half_iter, 3),
        y = c(
            dparameter$drift[nrow(dparameter)],  
            dparameter$bound[nrow(dparameter)],
            dparameter$ndt[nrow(dparameter)]),
        label = c("Drift", "Bound", "Non-decision time"))

    p1 <- ggplot(dparameter) +
        geom_point(aes(x = iteration, y = drift)) +
        geom_line(aes(x = iteration, y = drift)) +
        geom_hline(yintercept = dparameter$drift[nrow(dparameter)], linetype = 2) +
        geom_text(data = dtext1[label == "Drift"], 
            aes(x = x, y = y+0.2, label = round(y, 2)), size = 8) +
        theme_classic(base_size = 24)

    p2 <- ggplot(dparameter) +
        geom_point(aes(x = iteration, y = bound)) +
        geom_line(aes(x = iteration, y = bound)) +
        geom_hline(yintercept = dparameter$bound[nrow(dparameter)], linetype = 2) +
        geom_text(data = dtext1[label == "Bound"], 
            aes(x = x, y = y+0.2, label = round(y, 2)), size = 8) +
        theme_classic(base_size = 24)

    p3 <- ggplot(dparameter) +
        geom_point(aes(x = iteration, y = ndt)) +
        geom_line(aes(x = iteration, y = ndt)) +
        geom_hline(yintercept = dparameter$ndt[nrow(dparameter)], linetype = 2) +
        geom_text(data = dtext1[label == "Non-decision time"], 
            aes(x = x, y = y+0.2, label = round(y, 2)), size = 8) +
        theme_classic(base_size = 24)


    dtext2 <- data.table(x = half_iter, y = c(dlik$n2LL[nrow(dlik)]))

    p4 <- ggplot(dlik) +
        geom_point(aes(x = iteration, y = n2LL)) +
        geom_line(aes(x = iteration, y = n2LL)) +
        geom_text(data = dtext2, 
            aes(x = x, y = y+5000, label = round(y, 2)), 
            size = 8) +
        theme_classic(base_size = 24)

    p5 <- gridExtra::grid.arrange(p1, p2, p3, p4, nrow = 2)
    if (save) {
        if (is.null(filename)) {
            filename <- "images/output.png"
        }
        ggsave(filename, p5, width = 12, height = 8)
    }
    return(NULL)
}


plot_histograms <- function(dsim1_path, demp1_path, dsim2_path, demp2_path, 
    binsize = 30, output = "images/output.png") {
  require(data.table)
  require(ggplot2)
  require(gridExtra)

  # Example usage:
  # plot_histograms("data/age_text1_simulation.csv", "data/age_text1.csv", "data/age_text2_simulation.csv", "data/age_text2.csv")

  dsim1 <- fread(dsim1_path)
  demp1 <- fread(demp1_path)

  dsim2 <- fread(dsim2_path)
  demp2 <- fread(demp2_path)

  dsim2$A <- "Without child pedestrian"

  dsim1$R <- ifelse(dsim1$R == 0, "Select a child victim", 
      "Select an adult victim")
  demp1$R <- ifelse(demp1$R == 0, "Select a child victim", 
      "Select an adult victim")
  dsim2$R <- ifelse(dsim2$R == 0, "Select a young victim", 
      "Select an old victim")
  demp2$R <- ifelse(demp2$R == 0, "Select a young victim", 
      "Select an old victim")

  p1 <- ggplot() +
    geom_histogram(data = dsim1, aes(x = RT, fill = "Simulation Data"), 
      bins = binsize, alpha = 0.5) +
    geom_histogram(data = demp1, aes(x = RT, fill = "Empirical Data"), 
      bins = binsize, alpha = 0.5) +
    facet_grid(R ~ .) +
    ggtitle("With child pedestrian") +
    theme_classic(base_size = 24) +
    scale_fill_manual(values=c("Empirical Data"="blue", "Simulation Data"="red")) +
    theme(legend.position = "top",
          legend.title = element_blank())

  p2 <- ggplot() +
    geom_histogram(data = demp2, aes(x = RT, fill = "Empirical Data"), 
      bins = 35, alpha = 0.5) +
    geom_histogram(data = dsim2, aes(x = RT, fill = "Simulation Data"), 
      bins = 35, alpha = 0.5) +
    scale_y_continuous(limit = c(0, 55)) +
    facet_grid(R ~ .) +
    ggtitle("No child pedestrian") +
    theme_classic(base_size = 24) +
    scale_fill_manual(values=c("Empirical Data"="blue", "Simulation Data"="red")) +
    theme(legend.position = "top",
          legend.title = element_blank())
  
  p3 <- grid.arrange(p1, p2, nrow = 1)
  
  ggsave(output, p3, width = 12, height = 8)
}

