import Model
import numpy as np
import pandas as pd
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from IPython.display import Image
import Model_utility 
import os
from multiprocessing import Pool

os.chdir('/media/yslin/kakapu/02_Projects/Multi-choices_Github/tests/Model_Age_old')
print(os.getcwd())


def objective_function(x, RT, R, filename):
    v0 = x[0]
    b0 = x[1]
    ndt = x[2]
    
    # These three paraemters are just assumptions. You should treat them as the tuning parameters and 
    # search for the best ones, using the method, e.g., those found in a machine-learning textbook. 
    x0 = 0.0
    s0 = 1.5
    dx = 0.01
    dt = 0.01
    max_time = 14.0
    bias = "centre"
    method = "implicit"

    estimated_pdf = Model.test_solve_numerical(method, bias, v0, b0, s0, x0, dx, dt, max_time)
    res = Model_utility.calculate_LL(RT, R, estimated_pdf, dt, ndt)
    
    # Write the value of res to a file
    with open(filename, 'a') as f:
        f.write(str(res) + '\n')

    return res

def callback_aget1(xk):
    with open('data/estimate_age_text1.txt', 'a') as f:
            f.write('   '.join(map(str, xk)) + '\n')
    
def callback_aget2(xk):
    with open('data/estimate_age_text2.txt', 'a') as f:
            f.write('   '.join(map(str, xk)) + '\n')
  
def callback_agev1(xk):
    with open('data/estimate_age_video1.txt', 'a') as f:
            f.write('   '.join(map(str, xk)) + '\n')
    
def callback_agev2(xk):
    with open('data/estimate_age_video2.txt', 'a') as f:
            f.write('   '.join(map(str, xk)) + '\n')

df_aget1 = pd.read_csv('data/age_text1.csv')
df_aget2 = pd.read_csv('data/age_text2.csv')
df_agev1 = pd.read_csv('data/age_video1.csv')
df_agev2 = pd.read_csv('data/age_video2.csv')

RT_aget1 = df_aget1['RT'].to_numpy()
R_aget1 = df_aget1['R'].to_numpy()
RT_aget2 = df_aget2['RT'].to_numpy()
R_aget2 = df_aget2['R'].to_numpy()

RT_agev1 = df_agev1['RT'].to_numpy()
R_agev1 = df_agev1['R'].to_numpy()
RT_agev2 = df_agev2['RT'].to_numpy()
R_agev2 = df_agev2['R'].to_numpy()


n_maxiter = 150
initial_guess = [0.5, 0.5, 0.5]  # Initial guess for the parameters
filename_aget1 = 'data/likelihood_age_text1.txt'
filename_aget2 = 'data/likelihood_age_text2.txt'
filename_agev1 = 'data/likelihood_age_video1.txt'
filename_agev2 = 'data/likelihood_age_video2.txt'

def minimize_func(args):
    return minimize(objective_function, initial_guess, args[0], method='Nelder-Mead', options={'maxiter': n_maxiter}, callback=args[1])

with Pool(4) as p:
    res_list=p.map(minimize_func,[((RT_aget1,R_aget1,filename_aget1),callback_aget1),((RT_aget2,R_aget2,filename_aget2),callback_aget2),((RT_agev1,R_agev1,filename_agev1),callback_agev1),((RT_agev2,R_agev2,filename_agev2),callback_agev2)])
res1,res2,res3,res4=res_list


x0 = 0.0
s0 = 1.5
dx = 0.01
dt = 0.01
max_time = 14.0
bias = "centre"
method = "implicit"

# v0, b0
model_aget1 = Model.test_solve_numerical(method, bias, res1.x[0], res1.x[1], s0, x0, dx, dt, max_time)
model_aget2 = Model.test_solve_numerical(method, bias, res2.x[0], res2.x[1], s0, x0, dx, dt, max_time)
model_agev1 = Model.test_solve_numerical(method, bias, res3.x[0], res3.x[1], s0, x0, dx, dt, max_time)
model_agev2 = Model.test_solve_numerical(method, bias, res4.x[0], res4.x[1], s0, x0, dx, dt, max_time)
df_aget1.rename(columns={'R': 'TrueR'}, inplace=True)
df_aget2.rename(columns={'R': 'TrueR'}, inplace=True)
df_agev1.rename(columns={'R': 'TrueR'}, inplace=True)
df_agev2.rename(columns={'R': 'TrueR'}, inplace=True)

sim_aget1 = Model_utility.simulate(model_aget1, df_aget1, dt, res1.x[2]) # ndt
sim_aget2 = Model_utility.simulate(model_aget2, df_aget2, dt, res2.x[2])
sim_agev1 = Model_utility.simulate(model_agev1, df_agev1, dt, res3.x[2])
sim_agev2 = Model_utility.simulate(model_agev2, df_agev2, dt, res4.x[2])