rm(list = ls())
pkg <- c("data.table")
sapply(pkg, require, character.only = TRUE)
d <- read.csv("res1.csv", header = FALSE, sep = ",")
d$V1
nrow(d1)
which(d1$V1 == 1)

d1 <- read.csv("res2.csv", header = FALSE, sep = ",")
d1$V1
nrow(d1)
which(d1$V1 == 1)

evidence <- read.csv("evidence_vector.csv", header = FALSE, sep = ",")
length(evidence$V1)

d <- read.csv("res3.csv", header = FALSE, sep = ",")
d$V1
nrow(d)
which(d$V1 == 1)

d2 <- read.csv("res4.csv", header = FALSE, sep = ",")
d2$V1
nrow(d2)
which(d2$V1 == 1)

B <- 1
x0 <- 0.0
dx <- 0.1
sz <- 1.0
evidence_vector <- seq(-B, B, dx)
nx <- length(evidence_vector)
start <- round(x0 / dx)
shift_i <- start + 0.5 * (nx - 1)

x0/dx


B = 1
x0 = 0.0
sz = 1.0
dx = 0.01
evidence_vector <- seq(-B, B, dx)
nx <- length(evidence_vector)
start <- round(x0 / dx)
shift_i <- start + 0.5 * (nx - 1)


drift0 <- 1.0

x_bound <- 1.0
dx <- 0.1
dt <- 0.1

sign(x_bound) * drift0
out <- .5 * dt / dx * sign(x_bound) * drift0

