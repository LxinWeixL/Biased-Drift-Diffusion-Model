import Bias
import numpy as np
import matplotlib.pyplot as plt

# Case 1
B = 1
x0 = 0.0
sz = 1.0
dx = 0.1
time_vector = np.arange(0.0, 5.0, dx)
evidence_vector = np.arange(-B, B+dx, dx)

np.set_printoptions(precision=2, suppress=True)

if len(evidence_vector) <= 50:
    print (evidence_vector)
else:
    print("The evidence vector is too long to be printed.")

res1 = Bias.test_Bias_centre(evidence_vector)

# The user can assign a value for the initial starting point, x0, on the line of -B and B. 
x0_bias_favouring_positive_bound = 0.8 
res2 = Bias.test_Bias_point(x0_bias_favouring_positive_bound, dx, evidence_vector)
res3 = Bias.test_Bias_uniform(x0, sz, dx, time_vector, evidence_vector)
# res4 = Bias.test_Bias_range(x0, sz, dx, time_vector, evidence_vector)
res5 = Bias.test_Bias_Gaussian(x0, sz, dx, time_vector, evidence_vector)

np.savetxt("evidence_vector.csv", evidence_vector, delimiter=",")
np.savetxt("res1.csv", res1, delimiter=",")
np.savetxt("res2.csv", res2, delimiter=",")

fig, ax = plt.subplots(nrows=1, ncols=4, figsize=(12, 4))
ax[0].plot(evidence_vector, res1, color ='red', marker ='o')
ax[0].set_title('symmetric_starting_point')
ax[0].set_xlabel('Evidence value')
ax[0].set_ylabel('Probability density')

ax[1].plot(evidence_vector, res2, color ='red', marker ='o')
ax[1].set_title('point_starting_point')
ax[1].set_xlabel('Evidence value')

ax[2].plot(evidence_vector, res3, color ='red', marker ='o')
ax[2].set_title('uniform_starting_point')
ax[2].set_xlabel('Evidence value')

ax[3].plot(evidence_vector, res5, color ='red', marker ='o')
ax[3].set_title('Gaussian_starting_point')
ax[3].set_xlabel('Evidence value')
plt.savefig('images/four_bias_hypotheses.png', dpi=300)


# plt.plot(evidence_vector, res4, color ='red', marker ='o')
# plt.savefig('images/range_starting_point.png', dpi=300)

# Case 2----------------------
B = 1
x0 = 0.0
sz = 1.0
dx = 0.01
time_vector = np.arange(0.0, 5.0, dx)
evidence_vector = np.arange(-B, B+dx, dx)
res1 = Bias.test_Bias_centre(evidence_vector)

# The user can assign a value for the initial starting point, x0, on the line of -B and B. 
x0_bias_favouring_positive_bound = 0.8 
res2 = Bias.test_Bias_point(x0_bias_favouring_positive_bound, dx, evidence_vector)
res3 = Bias.test_Bias_uniform(x0, sz, dx, time_vector, evidence_vector)
# res4 = Bias.test_Bias_range(x0, sz, dx, time_vector, evidence_vector)
res5 = Bias.test_Bias_Gaussian(x0, sz, dx, time_vector, evidence_vector)

np.savetxt("res3.csv", res1, delimiter=",")
np.savetxt("res4.csv", res2, delimiter=",")


fig, ax = plt.subplots(nrows=1, ncols=4, figsize=(12, 4))
ax[0].plot(evidence_vector, res1, color ='red', marker ='o')
ax[0].set_title('symmetric_starting_point')
ax[0].set_xlabel('Evidence value')
ax[0].set_ylabel('Probability density')

ax[1].plot(evidence_vector, res2, color ='red', marker ='o')
ax[1].set_title('point_starting_point')
ax[1].set_xlabel('Evidence value')

ax[2].plot(evidence_vector, res3, color ='red', marker ='o')
ax[2].set_title('uniform_starting_point')
ax[2].set_xlabel('Evidence value')

ax[3].plot(evidence_vector, res5, color ='red', marker ='o')
ax[3].set_title('Gaussian_starting_point')
ax[3].set_xlabel('Evidence value')
plt.savefig('images/four_bias_hypotheses_case2.png', dpi=300)
