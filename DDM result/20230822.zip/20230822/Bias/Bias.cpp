#include <iostream>
#include <string>
#include <cctype> // tolower
#include <armadillo>
#include <boost/math/distributions/normal.hpp>

#include "Dependence.hpp"
#include "Bias.hpp"

#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <armadillo>

namespace py = pybind11;

py::array_t<double> armadilloToNumpy(const arma::mat &mat)
{
    // Get dimensions of the matrix
    ssize_t rows = mat.n_rows;
    ssize_t cols = mat.n_cols;

    // Create a Pybind11 array with the same shape as the Armadillo matrix
    py::array_t<double> result({rows, cols});

    // Get a pointer to the data in the Armadillo matrix
    const double *data = mat.memptr();

    // Get a pointer to the data in the Pybind11 array
    double *result_data = result.mutable_data();

    // Copy data from Armadillo matrix to Pybind11 array
    std::memcpy(result_data, data, sizeof(double) * rows * cols);

    return result;
}

py::array_t<double> test_Bias_centre(const py::array_t<double> &evidence_vector)
{
    py::buffer_info evidence_buffer = evidence_vector.request();
    if (evidence_buffer.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }

    double *evidence_ptr = static_cast<double *>(evidence_buffer.ptr);
    arma::vec evidence_vector_arma(evidence_ptr, evidence_buffer.size);

    Bias *ptr;

    ptr = new Bias("centre", "Bias"); // The most common mid-point initial evidence
    ptr->print_name();
    arma::vec output_vec = ptr->get_bias(evidence_vector_arma);
    delete ptr;
    py::array_t<double> out = armadilloToNumpy(output_vec);
    return out;
}

py::array_t<double> test_Bias_point(double x0, double dx, const py::array_t<double> &evidence_vector)
{
    py::buffer_info evidence_buffer = evidence_vector.request();
    if (evidence_buffer.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }

    double *evidence_ptr = static_cast<double *>(evidence_buffer.ptr);
    arma::vec evidence_vector_arma(evidence_ptr, evidence_buffer.size);

    Bias *ptr;

    // The user assigns one arbitrary starting point. The keyword "point" results in a
    // single starting point.
    ptr = new Bias("point", "Bias", x0, dx);
    ptr->print_name();
    arma::vec output_vec = ptr->get_bias(evidence_vector_arma);
    delete ptr;
    py::array_t<double> out = armadilloToNumpy(output_vec);
    return out;
}

py::array_t<double> test_Bias_uniform(double x0, double sz, double dx, const py::array_t<double> &time_vector,
                                      const py::array_t<double> &evidence_vector)
{
    py::buffer_info time_buffer = time_vector.request();
    py::buffer_info evidence_buffer = evidence_vector.request();
    if (time_buffer.ndim != 1 || evidence_buffer.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }

    double *time_ptr = static_cast<double *>(time_buffer.ptr);
    double *evidence_ptr = static_cast<double *>(evidence_buffer.ptr);
    arma::vec time_vector_arma(time_ptr, time_buffer.size);
    arma::vec evidence_vector_arma(evidence_ptr, evidence_buffer.size);

    Bias *ptr;
    // The keyword "uniform" results in a uniform distribution of starting points.
    ptr = new Bias("uniform", "Bias");
    ptr->print_name();
    arma::vec output_vec = ptr->get_bias(evidence_vector_arma);
    delete ptr;
    py::array_t<double> out = armadilloToNumpy(output_vec);
    return out;
}

py::array_t<double> test_Bias_range(double x0, double sz, double dx, const py::array_t<double> &time_vector,
                                    const py::array_t<double> &evidence_vector)
{
    py::buffer_info time_buffer = time_vector.request();
    py::buffer_info evidence_buffer = evidence_vector.request();
    if (time_buffer.ndim != 1 || evidence_buffer.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }

    double *time_ptr = static_cast<double *>(time_buffer.ptr);
    double *evidence_ptr = static_cast<double *>(evidence_buffer.ptr);
    arma::vec time_vector_arma(time_ptr, time_buffer.size);
    arma::vec evidence_vector_arma(evidence_ptr, evidence_buffer.size);

    Bias *ptr;

    // The keyword "range" results in a range-based distribution of starting points.
    ptr = new Bias("range", "Bias", sz, dx); // Uniform range
    ptr->print_name();
    arma::vec output_vec = ptr->get_bias(evidence_vector_arma);
    delete ptr;
    py::array_t<double> out = armadilloToNumpy(output_vec);
    return out;
}

py::array_t<double> test_Bias_Gaussian(double x0, double sz, double dx, const py::array_t<double> &time_vector,
                                       const py::array_t<double> &evidence_vector)
{
    py::buffer_info time_buffer = time_vector.request();
    py::buffer_info evidence_buffer = evidence_vector.request();
    if (time_buffer.ndim != 1 || evidence_buffer.ndim != 1)
    {
        throw std::runtime_error("Input array must be 1-dimensional");
    }

    double *time_ptr = static_cast<double *>(time_buffer.ptr);
    double *evidence_ptr = static_cast<double *>(evidence_buffer.ptr);
    arma::vec time_vector_arma(time_ptr, time_buffer.size);
    arma::vec evidence_vector_arma(evidence_ptr, evidence_buffer.size);

    Bias *ptr;

    // Gaussian distribution in the initial evidence space
    ptr = new Bias("Gaussian", "Bias", sz, dx);
    ptr->print_name();
    arma::vec output_vec = ptr->get_bias(evidence_vector_arma);
    delete ptr;
    py::array_t<double> out = armadilloToNumpy(output_vec);
    return out;
}

PYBIND11_MODULE(Bias, m)
{
    m.doc() = "Bias module";
    m.def("test_Bias_centre", &test_Bias_centre,
          "The initial evidence space and its density assuming a pair of symmetrical boundary.");
    m.def("test_Bias_point", &test_Bias_point,
          "The initial evidence space. The user assigns one point anywhere he/she wnats");
    m.def("test_Bias_uniform", &test_Bias_uniform,
          "The initial evidence space. The user requests to use a uniform distribution");
    m.def("test_Bias_range", &test_Bias_range,
          "The initial evidence space. The user requests to use range");
    m.def("test_Bias_Gaussian", &test_Bias_Gaussian,
          "The initial evidence space. The user requests to use a Gaussian distribution");
}
