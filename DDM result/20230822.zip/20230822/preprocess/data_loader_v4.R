rm(list = ls())
pkg <- c("data.table", "ggplot2", "psych", "plotrix")
tmp_sink <- sapply(pkg, require, character.only = TRUE)
setwd("/media/yslin/kakapu/02_Projects/Multi-choices_Github")

d <- fread("data/df_all.csv")
# Media (M) factor - a static pitcture versus motion pictures
#
# Age (A) factor - a stimulus with a child pedestrian versus a stimulus without
# a child pedestrian 
#
# Scenario (S) factor - AGE, GENDER, AGE+GENDER, meaning (1) choosing a pair of
# pedestrian of different age (same gender), (2) choosing a pair of pedestrian
# of different gender (male vs. female), but same age, (3) choosing a pair of
# pedestrian of different gender and age.
names(d) <- c("V1", "s", "M", "Scenario_ID", "Scenario_Type", "Age_L", "Age_R",
    "Gender_L", "Gender_R", "R", "RT", "Initial_AV_location",
    "Subject_Age", "Subject_Gender")
# A tibble: 2,556 × 14
#       V1     s M     Scenario_ID Scenario_Type Age_L Age_R Gender_L Gender_R
#    <int> <int> <chr>       <int> <chr>         <chr> <chr> <chr>    <chr>   
#  1     1     1 Video          11 AGE           old   child male     male    
#  2     2     1 Video          10 GENDER        old   old   male     female  
#  3     3     1 Video           3 AGE           young old   female   female  
#  4     4     1 Video           2 AGE+GENDER    young old   female   male    
#  5     5     1 Video          13 AGE+GENDER    old   child female   male    
#  6     6     1 Video           5 AGE           young child female   female  
#  7     7     1 Video           4 AGE+GENDER    child young male     female  
#  8     8     1 Video           8 AGE           child young male     male    
#  9     9     1 Video           1 GENDER        young young male     female  
# 10    10     1 Video           9 AGE+GENDER    young child male     female  
# ℹ 2,546 more rows
# ℹ 5 more variables: R <chr>, RT <dbl>, Initial_AV_location <chr>,
#   Subject_Age <int>, Subject_Gender <chr>
# ℹ Use `print(n = ...)` to see more rows
# tibble::as_tibble(d1)

unique(d$M)
unique(d$R)
psych::describeBy(d$RT, d$R)

unique(d$Initial_AV_location)
unique(d$Subject_Gender)
sort(unique(d$Subject_Age))

length(unique(d$s)) # 40
unique(d$Scenario_Type)
# "AGE"        "GENDER"     "AGE+GENDER" NA   
table(d$Scenario_Type)
# AGE AGE+GENDER     GENDER 
#    800       1119        477 

length(unique(d$Scenario_ID)) # 16
# Forty subjects took part in 16 task scenarios. The experimenter used
# Scenario 16 as a condition to test whether the subject paid attention
# to the task.

d[Scenario_ID == 16]

# Theoretical total number of trials is 2560, if
# we consider the control condition has the same number of trial
# as the other. 16 conditions, each has 4 repetitions, and 40 subjects.
16 * 4 * 40

nrow(d) # Why there is a four-trial difference? 

# Remove the NA control trials
d1 <- d[!is.na(d$Scenario_Type)]
nrow(d1) # 2396

# Remove that the RT is NA
d2 <- d1[!is.na(d1$RT)]
nrow(d2) # 2126

# AGE -----------
# Separate the levels in the S factor 
d3 <- d2[Scenario_Type == "AGE", c("s", "M", "RT", "R", "Scenario_Type", "Gender_L", "Gender_R", "Age_L", "Age_R")]
summary(d3$RT)

# From the interaction-plot I can examine, it looked like the age factor 
# has an effect, child vs (yound or old)
#
# Therefore, I assumed that the subject has a bias of not selecting the child 
# as the option to be run  over by the car. I divided the age factor into 
# two levels, child vs [adult] (level 1); old vs young (level 2)

d3$A <- ifelse(d3$Age_L == "child" & d3$Age_R == "young", 1,
        ifelse(d3$Age_L == "child" & d3$Age_R == "old",   1,
        ifelse(d3$Age_L == "young" & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "young" & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "young" & d3$Age_R == "old",   2,
        ifelse(d3$Age_L == "child" & d3$Age_R == "young", 1,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "young", 2,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "young", 2,
        ifelse(d3$Age_L == "child" & d3$Age_R == "old",   1,
        ifelse(d3$Age_L == "young" & d3$Age_R == "old",   2, NA))))))))))))

# Check if the ifelse worked as expected
unique(d3$A)
table(d3$A)
nrow(d3)
sum(table(d3$A))

# Match the behavioural response to the model upper and lower boundaries.
d3$TrueR <- ifelse(d3$Age_L == "child" & d3$Age_R == "old" & d3$R == "L", 0,
    ifelse(d3$Age_L == "child" & d3$Age_R == "young" & d3$R == "L", 0,
    ifelse(d3$Age_L == "child" & d3$Age_R == "young" & d3$R == "R", 1,
    ifelse(d3$Age_L == "child" & d3$Age_R == "young" & d3$R == "R", 1,

    ifelse(d3$Age_L == "old" & d3$Age_R == "child" & d3$R == "L", 1,
    ifelse(d3$Age_L == "old" & d3$Age_R == "young" & d3$R == "L", 1,
    ifelse(d3$Age_L == "old" & d3$Age_R == "child" & d3$R == "R", 0,
    ifelse(d3$Age_L == "old" & d3$Age_R == "young" & d3$R == "R", 0,
 
    ifelse(d3$Age_L == "young" & d3$Age_R == "child" & d3$R == "L", 1,
    ifelse(d3$Age_L == "young" & d3$Age_R == "old" & d3$R == "L", 0,
    ifelse(d3$Age_L == "young" & d3$Age_R == "child" & d3$R == "R", 0,
    ifelse(d3$Age_L == "young" & d3$Age_R == "old" & d3$R == "R", 1, NA))))))))))))


nrow(d3) # 722
unique(d3$TrueR)
table(d3$TrueR)

# The hypothesis is that When the level involves a child, people tend to 
# select the adult as the victim, whereas, when the level does not 
# involve a child, people tend to select the young person as the victim. 
# However, this appear not exceeed the significant level. That is, whether 
# the latter is true and general is not clear. It could result from noise.
sum(table(d3$TrueR))

# Remove 20 outliers ----------------------------
lower <- mean(d3$RT) - 2 * sd(d3$RT)
upper <- mean(d3$RT) + 2 * sd(d3$RT)

d4 <- d3[d3$RT < upper & d3$RT > lower, c("s", "RT", "M", "Scenario_Type", "TrueR", "A")]
nrow(d4) 
table(d4$TrueR)
nrow(d3) - nrow(d4)

# 0   1 
# 217 485 

table(d4$TrueR, d4$A)
#    involve child   without child
#   0          108             109
#   1          311             174



freq_table <- table(d4$TrueR, d4$A) #matrix(c(108, 311, 109, 175), nrow = 2)
freq_tbl_text  <- table( d4[M=="Text"]$TrueR, d4[M=="Text"]$A)
freq_tbl_video <- table( d4[M=="Video"]$TrueR, d4[M=="Video"]$A)
chisq.test(freq_table)
chisq.test(freq_tbl_text)
chisq.test(freq_tbl_video)
#         Pearson's Chi-squared test with Yates' continuity correction
# data:  freq_table
# X-squared = 4.6882, df = 1, p-value = 0.03037
# X-squared = 7.2957, df = 1, p-value = 0.006912
# X-squared = 12.248, df = 1, p-value = 0.0004657

summary(d4[TrueR==0]$RT)
#    Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#   1.248   2.881   4.140   4.540   5.722  13.498 
summary(d4[TrueR==1]$RT)
#    Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
#   1.014   2.680   3.852   4.243   5.364  13.298
sort(d4[, .N, .(s)]$N)
# [1] 10 11 12 13 14 15 15 16 16 17 17 17 17 17 17 17 18 18 18 18 18 18 19 19 19
# [26] 19 19 19 19 20 20 20 20 20 20 20 20 20 20 20

d4text <- d4[M=="Text"]
d4video <- d4[M=="Video"]
names(d4text) <- c("s", "RT", "M", "Scenario_Type", "R", "A")
names(d4video) <- c("s", "RT", "M", "Scenario_Type", "R", "A")
write.csv(d4text[A==1], "data/age_text1.csv", row.names = FALSE)
write.csv(d4text[A==2], "data/age_text2.csv", row.names = FALSE)
write.csv(d4video[A==1], "data/age_video1.csv", row.names = FALSE)
write.csv(d4video[A==2], "data/age_video2.csv", row.names = FALSE)


# GENDER -----------
d3 <- d2[Scenario_Type == "GENDER", c("s", "M", "RT", "R", "Scenario_Type", "Gender_L", "Gender_R", "Age_L", "Age_R")]
d3$TrueR <- ifelse(d3$Gender_L == "male"  & d3$Gender_R == "female" & d3$R == "L", 0,
            ifelse(d3$Gender_L == "male"  & d3$Gender_R == "female" & d3$R == "R", 1,
            ifelse(d3$Gender_L == "female" & d3$Gender_R == "male" & d3$R == "R", 0,
            ifelse(d3$Gender_L == "female" & d3$Gender_R == "male" & d3$R == "L", 1, NA))))

nrow(d3) # 722
unique(d3$TrueR)
table(d3$TrueR)
sum(table(d3$TrueR))

# Remove outliers 
lower <- mean(d3$RT) - 2 * sd(d3$RT)
upper <- mean(d3$RT) + 2 * sd(d3$RT)

d4 <- d3[d3$RT < upper & d3$RT > lower, c("s", "RT", "M", "Scenario_Type", "TrueR")]
nrow(d4) 
table(d4$TrueR)
nrow(d3) - nrow(d4) # 12 trials were removed

1 - nrow(d4) / nrow(d3)
# 0.02912621; 2.9% of the data were removed. That is, 12 trials.
nrow(d4)
table(d4$TrueR)
nrow(d3) - nrow(d4)
table(d4$TrueR) / sum(table(d4$TrueR))

# The overall choice probability towards crashing the young person is 0.31.
#   0   1 
# 217 485 
table(d4$TrueR) / nrow(d4)
#   0      1 
# 0.7625 0.2375 

sort(d4[, .N, .(s)]$N)
# [1]  4  5  5  7  8  8  8  9  9  9  9  9  9  9  9  9 10 10 10 10 11 11 11 11 11
# [26] 11 12 12 12 12 12 12 12 12 12 12 12 12 12 12
describe(d4$RT)
#    n mean   sd median trimmed  mad  min   max range skew kurtosis  se
#  400 4.97 2.07   4.81     4.8 1.99 1.41 12.65 11.23 0.92     1.12 0.1


d4text <- d4[M=="Text"]
d4video <- d4[M=="Video"]
names(d4text) <- c("s", "RT", "M", "Scenario_Type", "R")
names(d4video) <- c("s", "RT", "M", "Scenario_Type", "R")
write.csv(d4text, "data/gender_text.csv", row.names = FALSE)
write.csv(d4video, "data/gender_video.csv", row.names = FALSE)

# MIXED -----------
d3 <- d2[Scenario_Type == "AGE+GENDER", c("s", "M", "RT", "R", "Scenario_Type", "Gender_L", "Gender_R", "Age_L", "Age_R")]

d3$A <- ifelse(d3$Age_L == "child" & d3$Age_R == "young", 1,
        ifelse(d3$Age_L == "child" & d3$Age_R == "old",   1,
        ifelse(d3$Age_L == "young" & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "child", 1,
        ifelse(d3$Age_L == "young" & d3$Age_R == "old",   2,
        ifelse(d3$Age_L == "old"   & d3$Age_R == "young", 2, NA))))))

d3$G <- ifelse(d3$Gender_L == "male"   & d3$Gender_R == "female", 1,
        ifelse(d3$Gender_L == "female" & d3$Gender_R == "male", 1,
        ifelse(d3$Gender_L == "male"   & d3$Gender_R == "male", 2,
        ifelse(d3$Gender_L == "female" & d3$Gender_R == "female", 2, NA))))
        
unique(d3$A)
table(d3$A)
nrow(d3)
sum(table(d3$A))

d3$TrueR <- ifelse(d3$Age_L == "child" & d3$Age_R == "old" & d3$R == "L", 0,
    ifelse(d3$Age_L == "child" & d3$Age_R == "young" & d3$R == "L", 0,
    ifelse(d3$Age_L == "child" & d3$Age_R == "young" & d3$R == "R", 1,
    ifelse(d3$Age_L == "child" & d3$Age_R == "old" & d3$R == "R", 1,

    ifelse(d3$Age_L == "old" & d3$Age_R == "child" & d3$R == "L", 1,
    ifelse(d3$Age_L == "old" & d3$Age_R == "young" & d3$R == "L", 1,
    ifelse(d3$Age_L == "old" & d3$Age_R == "child" & d3$R == "R", 0,
    ifelse(d3$Age_L == "old" & d3$Age_R == "young" & d3$R == "R", 0,
 
    ifelse(d3$Age_L == "young" & d3$Age_R == "child" & d3$R == "L", 1,
    ifelse(d3$Age_L == "young" & d3$Age_R == "old" & d3$R == "L", 0,
    ifelse(d3$Age_L == "young" & d3$Age_R == "child" & d3$R == "R", 0,
    ifelse(d3$Age_L == "young" & d3$Age_R == "old" & d3$R == "R", 1, NA))))))))))))

d3[is.na(TrueR)]
nrow(d3) # 722
unique(d3$TrueR)
table(d3$TrueR)
sum(table(d3$TrueR))

describe(d3$RT)
# vars   n mean   sd median trimmed  mad  min  max range skew kurtosis   se
# X1    1 992 5.09 3.95   4.26    4.44 2.08 0.98 41.8 40.82 4.23    25.57 0.13

# Remove outliers 
lower <- mean(d3$RT) - 2 * sd(d3$RT)
upper <- mean(d3$RT) + 2 * sd(d3$RT)
# Remove 20 outliers
d4 <- d3[d3$RT < upper & d3$RT > lower, c("s", "RT", "M", "TrueR", "A")]

1 - nrow(d4) / nrow(d3)
# 0.03629032; 3.6% of the data were removed. That is, 12 trials.

freq_table <- table(d4$TrueR, d4$A) #matrix(c(108, 311, 109, 175), nrow = 2)
freq_tbl_text  <- table( d4[M=="Text"]$TrueR, d4[M=="Text"]$A)
freq_tbl_video <- table( d4[M=="Video"]$TrueR, d4[M=="Video"]$A)
chisq.test(freq_table)
chisq.test(freq_tbl_text)
chisq.test(freq_tbl_video)
#    Pearson's Chi-squared test with Yates' continuity correction

# data:  freq_table
# X-squared = 4.9369, df = 1, p-value = 0.02629
# X-squared = 2.6939, df = 1, p-value = 0.1007
# X-squared = 1.9256, df = 1, p-value = 0.1652


table(d4$TrueR)
nrow(d3) - nrow(d4)
table(d4$TrueR) / nrow(d4)
# 0         1 
# 0.3514644 0.6485356 

sort(d4[, .N, .(s)]$N)
# [1] 14 17 17 18 18 20 20 21 21 21 21 22 22 22 23 23 23 24 25 25 25 25 26 26 26
# [26] 26 26 27 27 27 27 27 28 28 28 28 28 28 28 28

describe(d4$RT)
#    n mean   sd median trimmed  mad  min   max range skew kurtosis   se
#  956 4.49 2.04    4.2    4.31 1.97 0.98 12.63 11.65 0.99      1.3 0.07

d4text <- d4[M=="Text"]
d4video <- d4[M=="Video"]
names(d4text) <- c( "s", "RT", "M", "R", "A")
names(d4video) <- c("s", "RT", "M", "R", "A")

write.csv(d4text[A==1], "data/mixed_text1.csv", row.names = FALSE)
write.csv(d4text[A==2], "data/mixed_text2.csv", row.names = FALSE)
write.csv(d4video[A==1], "data/mixed_video1.csv", row.names = FALSE)
write.csv(d4video[A==2], "data/mixed_video2.csv", row.names = FALSE)


