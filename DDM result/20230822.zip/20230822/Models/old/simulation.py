import Model
import numpy as np
import pandas as pd
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from IPython.display import Image
import Model_utility 
import pickle
import os
# from multiprocessing import Pool
os.chdir('/media/yslin/kakapu/02_Projects/Multi-choices_Github/')

ndataset = 11

dataset = ['data/age_text1.csv', 'data/age_text2.csv', 'data/age_video1.csv', 'data/age_video2.csv',
           'data/gender_text.csv', 'data/gender_video.csv',
           'data/mixed_text1.csv', 'data/mixed_text2.csv', 'data/mixed_video1.csv', 'data/mixed_video2.csv'
          ]

filepath = 'data/fits/result'
savepath = 'data/simulation/simdata'
bias = "point"
method = "implicit"
dx = 0.01
dt = 0.01
bound0 = 3.0  # Fixed bound0 at 3.0. You should run a grid search to tune this parameter to find the best case that fit the data.
noise0 = 2.5
max_time = 14.0


for i, data in enumerate(dataset):
    filename = filepath + str(i) + '.pkl'
    with open(filename, 'rb') as f:
        res = pickle.load(f)
        
    print(res.success)
    drift0 = res.x[0]
    x0 = res.x[1]
    ndt = res.x[2] 
    df = pd.read_csv(data)
    num_rows = df.shape[0]

    pdf = Model.test_solve_numerical(method, bias, drift0, bound0, noise0, x0, dx, dt, max_time)
    sim_responses = Model_utility.simulate_simple(pdf, num_rows, dt, ndt)
    simdata = {'RT':  sim_responses[1], 'R':  sim_responses[0]}
    simdf = pd.DataFrame(simdata)
    save_filename = savepath + str(i) + '.csv'
    simdf.to_csv(save_filename, index=False)

