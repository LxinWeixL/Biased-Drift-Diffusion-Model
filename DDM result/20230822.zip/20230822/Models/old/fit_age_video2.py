import Model
import numpy as np
import pandas as pd
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from IPython.display import Image
import Model_utility 
import pickle
import os
from multiprocessing import Pool

os.chdir('/media/yslin/kakapu/02_Projects/Multi-choices_Github/')

def objective_function(x, RT, R, filename):
    drift0 = x[0]
    start_point = x[1]
    ndt = x[2]

    bound0 = 3.0  # Fixed bound0 at 3.0. You should run a grid search to tune this parameter to find the best case that fit the data.
    noise0 = 2.5
    dx = 0.01
    dt = 0.01
    max_time = 14.0

    bias = "point"
    method = "implicit"
    
    estimated_pdf = Model.test_solve_numerical(method, bias, drift0, bound0, noise0, start_point, dx, dt, max_time)

    res = Model_utility.calculate_LL(RT, R, estimated_pdf, dt, ndt)
    with open(filename, 'a') as f:
        f.write(str(res) + '\n')

    return res
   

max_iteration = 150
ncore = 1

dataset = ['data/age_video2.csv'
          ]

initial_guess = [0.5, 0.5, 0.5]  

def process_data(data):
    index, data = data
    df = pd.read_csv(data)
    RT = df['RT'].to_numpy()
    R = df['R'].to_numpy()
    filename1 = 'data/likelihood' + str(index) + '.csv'
    filename2 = 'data/estimate' + str(index) + '.csv'
    filename3 = 'data/result' + str(index) + '.pkl'
    
    def callback_with_filename(xk):
        with open(filename2, 'a') as f:
            f.write('   '.join(map(str, xk)) + '\n')

    res1 = minimize(objective_function, initial_guess, (RT, R, filename1), method='Nelder-Mead', options={'maxiter': max_iteration}, callback=callback_with_filename)

    with open(filename3, 'wb') as f:
        pickle.dump(res1, f)

if __name__ == '__main__':
    with Pool(ncore) as p:
        p.map(process_data, enumerate(dataset))
