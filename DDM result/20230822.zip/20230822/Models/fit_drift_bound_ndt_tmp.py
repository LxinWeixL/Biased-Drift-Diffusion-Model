import Model
import numpy as np
import pandas as pd
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from IPython.display import Image
import Model_utility 
import pickle
import os
from multiprocessing import Pool

import time


def plot_rt_histogram(df1, df2, binsize=30, filename='histogram.png', titlename = 'Histogram'):
    # Create a boolean mask for rows where 'R' is 0
    mask0 = df1['R'] == 0
    mask1 = df2['R'] == 0

    # Create a boolean mask for rows where 'R' is 1
    mask2 = df1['R'] == 1
    mask3 = df2['R'] == 1

    # Use the boolean masks to extract the 'RT' values for each category of 'R'
    RT0 = df1.loc[mask0, 'RT']
    RT1 = df2.loc[mask1, 'RT']
    RT2 = df1.loc[mask2, 'RT']
    RT3 = df2.loc[mask3, 'RT']

    # Plot the histograms of the 'RT' values for each category of 'R'
    plt.hist(RT0, bins=binsize, alpha=0.5, label='df1 R=0', color='blue')
    plt.hist(RT1, bins=binsize, alpha=0.5, label='df2 R=0', color='red')
    plt.hist(RT2, bins=binsize, alpha=0.5, label='df1 R=1', color='green')
    plt.hist(RT3, bins=binsize, alpha=0.5, label='df2 R=1', color='orange')
    
    plt.xlabel('RT')
    plt.ylabel('Frequency')
    titlename = titlename + '; df1 = Data; df2 = Simulation' 
    plt.title(titlename)
    plt.legend()
    
    # Save the figure to a png file
    plt.savefig(filename)
    


def objective_function(x, RT, R, bias, filename):
    drift0 = x[0]
    
    bound0 = x[1]
    
    ndt = x[2]

    noise0 = 2.5
    dx = 0.01
    dt = 0.01
    max_time = 14.0
    starting_point = 0.0

    method = "implicit"
    
    estimated_pdf = Model.test_solve_numerical(method, bias, drift0, bound0, noise0, starting_point, dx, dt, max_time)

    res = Model_utility.calculate_LL(RT, R, estimated_pdf, dt, ndt)
    with open(filename, 'a') as f:
        f.write(str(res) + '\n')

    return res
   
def process_data(data):
    max_iteration = 150
    initial_guess = [0.5, 0.5, 0.5]  
    filepath = 'data/Model0/fits/result'
    savepath = 'data/Model0/simulation/simdata'
    bias = "centre"
    method = "implicit"
    dx = 0.01
    dt = 0.01
    noise0 = 2.5
    max_time = 14.0

    index, data = data
    df = pd.read_csv(data)
    RT = df['RT'].to_numpy()
    R = df['R'].to_numpy()
    filename1 = 'data/Model0/fits/likelihood' + str(index) + '.csv'
    filename2 = 'data/Model0/fits/estimate' + str(index) + '.csv'
    filename3 = filepath + str(index) + '.pkl'
    
    def callback_with_filename(xk):
        with open(filename2, 'a') as f:
            f.write('   '.join(map(str, xk)) + '\n')

    res = minimize(objective_function, initial_guess, (RT, R, bias, filename1), method='Nelder-Mead', options={'maxiter': max_iteration}, callback=callback_with_filename)

    with open(filename3, 'wb') as f:
        pickle.dump(res, f)

    drift0 = res.x[0]
    bound0 = res.x[1]
    ndt = res.x[2] 
    starting_point = 0.0

    num_rows = df.shape[0]

    pdf = Model.test_solve_numerical(method, bias, drift0, bound0, noise0, starting_point, dx, dt, max_time)
    sim_responses = Model_utility.simulate_simple(pdf, num_rows, dt, ndt)
    simdata = {'RT':  sim_responses[1], 'R':  sim_responses[0]}
    simdf = pd.DataFrame(simdata)
    save_filename = savepath + str(index) + '.csv'
    simdf.to_csv(save_filename, index=False)
    
    hist_name = 'images/Model0/histogram' + str(index) + '.png'
    plot_rt_histogram(df, simdf, 30, hist_name, ' Histogram'+str(index))





if __name__ == '__main__':
    os.chdir('/media/yslin/kakapu/02_Projects/Multi-choices_Github/')
    ncore = 7

    dataset = ['data/subsets/age_text1.csv', 'data/subsets/age_video1.csv',
           'data/subsets/age_text2.csv', 'data/subsets/age_video2.csv',
           'data/subsets/gender_text.csv', 'data/subsets/gender_video.csv',
           'data/subsets/mixed_text1.csv', 'data/subsets/mixed_video1.csv', 
           'data/subsets/mixed_text2.csv', 'data/subsets/mixed_video2.csv'
          ]

    start_time = time.time()
    with Pool(ncore) as p:
        p.map(process_data, enumerate(dataset))

    end_time = time.time()
    print(f'The code took {end_time - start_time:.2f} seconds to run.')
