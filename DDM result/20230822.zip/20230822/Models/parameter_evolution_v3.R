rm(list = ls())
pkg <- c("data.table", "ggplot2", "gridExtra")
tmp_sink <- sapply(pkg, require, character.only = TRUE)
setwd("/media/yslin/kakapu/02_Projects/Multi-choices_Github")

# Plot the evolution of parameter ------------
plot_evolution <- function(input1, input2, save = TRUE, output_name = NULL) {

    dparameter <- fread(input1)
    dlik <- fread(input2)

    dparameter$iteration <- 1:nrow(dparameter)
    dlik$iteration <- 1:nrow(dlik)

    names(dparameter) <- c("drift", "x0", "ndt", "iteration")
    names(dlik) <- c("n2LL", "iteration")

    half_iter <- nrow(dparameter)/ 2

    dtext1 <- data.table(
        x = rep(half_iter, 3),
        y = c(
            dparameter$drift[nrow(dparameter)],  
            dparameter$x0[nrow(dparameter)],
            dparameter$ndt[nrow(dparameter)]),
        label = c("Drift", "Starting evidence", "Non-decision time"))

    p1 <- ggplot(dparameter) +
        geom_point(aes(x = iteration, y = drift)) +
        geom_line(aes(x = iteration, y = drift)) +
        geom_hline(yintercept = dparameter$drift[nrow(dparameter)], 
            linetype = 2) +
        geom_text(data = dtext1[label == "Drift"], 
            aes(x = x, y = y+0.2, label = round(y, 2)), size = 8) +
        theme_classic(base_size = 24)

    p2 <- ggplot(dparameter) +
        geom_point(aes(x = iteration, y = x0)) +
        geom_line(aes(x = iteration, y = x0)) +
        geom_hline(yintercept = dparameter$x0[nrow(dparameter)], 
            linetype = 2) +
        geom_text(data = dtext1[label == "Starting evidence"], 
            aes(x = x, y = y+0.2, label = round(y, 2)), size = 8) +
        theme_classic(base_size = 24)

    p3 <- ggplot(dparameter) +
        geom_point(aes(x = iteration, y = ndt)) +
        geom_line(aes(x = iteration, y = ndt)) +
        geom_hline(yintercept = dparameter$ndt[nrow(dparameter)], 
            linetype = 2) +
        geom_text(data = dtext1[label == "Non-decision time"], 
            aes(x = x, y = y+0.2, label = round(y, 2)), size = 8) +
        theme_classic(base_size = 24)


    dtext2 <- data.table(x = half_iter, y = c(dlik$n2LL[nrow(dlik)]))
    yjitter <- 0.05*dlik$n2LL[nrow(dlik)]

    p4 <- ggplot(dlik) +
        geom_point(aes(x = iteration, y = n2LL)) +
        geom_line(aes(x = iteration, y = n2LL)) +
        geom_text(data = dtext2, 
            aes(x = x+30, y = y + yjitter, label = round(y, 2)), 
            size = 8) +
        theme_classic(base_size = 24)

    p5 <- gridExtra::grid.arrange(p1, p2, p3, p4, nrow = 2)
    if (save) {
        ggsave(filename=output_name, p5, width = 12, height = 8)
    }

    return(NULL)

}

arrange_files <- function(obj) {
    split_vec <- strsplit(obj, "(?<=[A-Za-z])(?=[0-9])|\\.csv", perl = TRUE)
    index <- order(as.numeric( sapply(split_vec, function(x) x[2]) ))
    obj[index]
}

likelihood_files <- list.files('data/fits', 'likelihood[0-9]*')
estimate_files <- list.files('data/fits', 'estimate[0-9]*')

lfiles <- arrange_files(likelihood_files)
efiles <- arrange_files(estimate_files)
nfile <- length(lfiles)

for(i in 1:nfile) {
    j <- i-1
    fn <- paste0('images/output', j, '.png')
    lfile <- paste0('data/fits/', lfiles[i])
    efile <- paste0('data/fits/', efiles[i])
    tmp <- plot_evolution(efile, lfile, save = TRUE, output_name = fn)
}


# Plot the goodness-of-fit -----------------------
dataset <- c('data/age_text1.csv', 'data/age_text2.csv', 'data/age_video1.csv',
          'data/age_video2.csv', 'data/gender_text.csv', 
          'data/gender_video.csv', 'data/mixed_text1.csv',
          'data/mixed_text2.csv', 'data/mixed_video1.csv', 'data/mixed_video2.csv')
ndataset <- length(dataset)

simulation_path <-'data/simulation/simdata'

for(i in 1:ndataset) {
    j <- i-1
    simulation_file <- paste0(simulation_path, j, '.csv')
    empirical_file <- dataset[i]
    dsim <- fread(simulation_file)
    demp <- fread(empirical_file)
    title_name <- dataset[i]

    p1 <- ggplot() +
        geom_histogram(data = demp, aes(x = RT, fill = "Empirical Data"), 
                 bins = 35, alpha = 0.5) +
        geom_histogram(data = dsim, aes(x = RT, fill = "Simulation Data"), 
                 bins = 35, alpha = 0.5) +
        # scale_y_continuous(limit = c(0, 55)) +
        ggtitle(title_name) +
        facet_grid(R ~ .) +
        theme_classic(base_size = 24) +
        scale_fill_manual(values=c("Empirical Data"="blue", "Simulation Data"="red")) +
        theme(legend.position = "top",
            legend.title = element_blank())

    output_name <- paste0('images/goodness-of-fit/fit', i, '.png')
    ggsave(output_name, p1, width = 12, height = 8)

}


